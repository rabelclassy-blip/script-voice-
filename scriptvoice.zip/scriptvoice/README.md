# ScriptVoice

Paste an AI-generated script, pick a tone (natural, funny, inspiring, threatening, dramatic, sarcastic, hyped, calm, heartfelt), get a human-sounding rewrite. Email/password auth, saved versions, free + Pro tiers via Stripe (test mode ready).

**Stack:** Flask, SQLite, Anthropic API, Stripe Checkout. Vanilla JS, no build step.

## Run locally

```bash
python3 -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                # then fill it in (see below)
python app.py                                       # http://localhost:5000
```

The app works without Stripe keys (everyone stays on Free). Without `ANTHROPIC_API_KEY`, rewriting returns a clear error.

## Environment variables

| Variable | Required | Notes |
|---|---|---|
| `SECRET_KEY` | yes (prod) | Long random string: `python -c "import secrets;print(secrets.token_hex(32))"` |
| `ANTHROPIC_API_KEY` | yes | From console.anthropic.com |
| `ANTHROPIC_MODEL` | no | Default `claude-sonnet-5-5`. Use a Haiku model for cheaper, faster rewrites |
| `APP_ENV` | no | Set `production` when deployed (secure cookies, no debug) |
| `BASE_URL` | yes (prod) | Public URL, no trailing slash. Used for Stripe redirects |
| `DATABASE_PATH` | no | SQLite file path. Default `data.db` |
| `APP_NAME` | no | Brand name shown everywhere |
| `FREE_DAILY_LIMIT` / `PRO_DAILY_LIMIT` | no | Rewrites per day. Defaults 5 / 200 |
| `FREE_VERSION_LIMIT` | no | Saved versions on Free. Default 5 |
| `PRO_PRICE_LABEL` | no | Display only (e.g. `$9`). Match your Stripe price |
| `STRIPE_SECRET_KEY` | for billing | `sk_test_...` in test mode |
| `STRIPE_PRICE_ID` | for billing | `price_...` of a recurring monthly price |
| `STRIPE_WEBHOOK_SECRET` | for billing | `whsec_...` |

## Stripe test mode (local)

1. Stripe Dashboard (test mode) → Products → add a recurring monthly price → copy its `price_...` ID.
2. Copy your `sk_test_...` key. Put both in `.env`.
3. Dashboard → Settings → Billing → **Customer portal** → activate it (needed for "Manage billing").
4. Install the [Stripe CLI](https://stripe.com/docs/stripe-cli), then run:
   `stripe listen --forward-to localhost:5000/billing/webhook`
   Copy the printed `whsec_...` into `STRIPE_WEBHOOK_SECRET` and restart the app.
5. Sign up, click **Upgrade**, pay with card `4242 4242 4242 4242` (any future date, any CVC). You should flip to Pro within seconds.

## Deploy (Render, ~10 minutes)

1. Push this folder to a GitHub repo.
2. Render → New → **Web Service** → pick the repo.
   - Build: `pip install -r requirements.txt`
   - Start: `gunicorn app:app --workers 2 --bind 0.0.0.0:$PORT`
3. **Add a persistent disk** (mount path `/var/data`) and set `DATABASE_PATH=/var/data/app.db`. SQLite on Render's default filesystem is wiped on every deploy. Disks need a paid instance.
4. Set env vars: `APP_ENV=production`, `SECRET_KEY`, `BASE_URL` (your `https://...onrender.com` URL), `ANTHROPIC_API_KEY`, and the Stripe vars.
5. Stripe Dashboard → Developers → Webhooks → **Add endpoint**: `https://YOUR_URL/billing/webhook`, events `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`. Copy its signing secret into `STRIPE_WEBHOOK_SECRET` and redeploy.
6. Visit `/healthz` (should say `ok`), then run a test purchase.

Railway and Fly.io work the same way (the `Procfile` is included). Always attach a volume for the database.

**Going live with payments:** create the product/price in live mode, swap in `sk_live_...`, the live `price_...` and a new live webhook secret.

## Known gaps before you scale

- No CSRF tokens on the login/signup forms (cookies are `SameSite=Lax`). Add Flask-WTF.
- No login rate limiting, email verification or password reset. Add Flask-Limiter and an email provider.
- Add Terms and Privacy pages before charging anyone.
- Move to Postgres once you outgrow a single instance.
- Don't promise users that output will pass AI detectors. Nothing can guarantee that.
